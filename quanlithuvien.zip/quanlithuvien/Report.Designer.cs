﻿namespace quanlithuvien
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnExit = new Button();
            dataGridView1 = new DataGridView();
            txtReportID = new TextBox();
            txtBookID = new TextBox();
            txtReaderID = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            dtpBorrowingDate = new DateTimePicker();
            dtpReturnDate = new DateTimePicker();
            label7 = new Label();
            txtStaff = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(1027, 127);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(188, 58);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += button1_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(1027, 216);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(188, 58);
            btnUpdate.TabIndex = 0;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += button2_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(1027, 309);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(188, 58);
            btnDelete.TabIndex = 0;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(1027, 399);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(222, 135);
            btnExit.TabIndex = 0;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(45, 586);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 102;
            dataGridView1.RowTemplate.Height = 49;
            dataGridView1.Size = new Size(1237, 460);
            dataGridView1.TabIndex = 1;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // txtReportID
            // 
            txtReportID.Location = new Point(327, 124);
            txtReportID.Name = "txtReportID";
            txtReportID.Size = new Size(515, 47);
            txtReportID.TabIndex = 2;
            // 
            // txtBookID
            // 
            txtBookID.Location = new Point(325, 274);
            txtBookID.Name = "txtBookID";
            txtBookID.Size = new Size(513, 47);
            txtBookID.TabIndex = 2;
            // 
            // txtReaderID
            // 
            txtReaderID.Location = new Point(325, 196);
            txtReaderID.Name = "txtReaderID";
            txtReaderID.Size = new Size(515, 47);
            txtReaderID.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(45, 127);
            label1.Name = "label1";
            label1.Size = new Size(144, 41);
            label1.TabIndex = 3;
            label1.Text = "Report ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(45, 202);
            label2.Name = "label2";
            label2.Size = new Size(147, 41);
            label2.TabIndex = 3;
            label2.Text = "Reader ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(45, 274);
            label3.Name = "label3";
            label3.Size = new Size(123, 41);
            label3.TabIndex = 3;
            label3.Text = "Book ID";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(45, 424);
            label4.Name = "label4";
            label4.Size = new Size(225, 41);
            label4.TabIndex = 3;
            label4.Text = "Borrowing Date";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(45, 487);
            label5.Name = "label5";
            label5.Size = new Size(175, 41);
            label5.TabIndex = 3;
            label5.Text = "Return Date";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(403, 9);
            label6.Name = "label6";
            label6.Size = new Size(647, 81);
            label6.TabIndex = 3;
            label6.Text = "Report Management";
            // 
            // dtpBorrowingDate
            // 
            dtpBorrowingDate.Location = new Point(327, 424);
            dtpBorrowingDate.Name = "dtpBorrowingDate";
            dtpBorrowingDate.Size = new Size(515, 47);
            dtpBorrowingDate.TabIndex = 4;
            // 
            // dtpReturnDate
            // 
            dtpReturnDate.Location = new Point(327, 487);
            dtpReturnDate.Name = "dtpReturnDate";
            dtpReturnDate.Size = new Size(515, 47);
            dtpReturnDate.TabIndex = 4;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(45, 352);
            label7.Name = "label7";
            label7.Size = new Size(113, 41);
            label7.TabIndex = 3;
            label7.Text = "Staff ID";
            // 
            // txtStaff
            // 
            txtStaff.Location = new Point(325, 346);
            txtStaff.Name = "txtStaff";
            txtStaff.Size = new Size(513, 47);
            txtStaff.TabIndex = 2;
            // 
            // Report
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1413, 1163);
            Controls.Add(dtpReturnDate);
            Controls.Add(dtpBorrowingDate);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(label1);
            Controls.Add(txtReaderID);
            Controls.Add(txtStaff);
            Controls.Add(txtBookID);
            Controls.Add(txtReportID);
            Controls.Add(dataGridView1);
            Controls.Add(btnExit);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Name = "Report";
            Text = "Report";
            Load += Report_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnExit;
        private DataGridView dataGridView1;
        private TextBox txtReportID;
        private TextBox txtBookID;
        private TextBox txtReaderID;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private DateTimePicker dtpBorrowingDate;
        private DateTimePicker dtpReturnDate;
        private Label label7;
        private TextBox txtStaff;
    }
}