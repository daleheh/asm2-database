﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace quanlithuvien
{
    public partial class Reader : Form
    {
        public Reader()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f = new MainForm();
            f.Show();
        }

        public void LoadData()
        {
            // Create columns
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.HeaderText = "ReaderID";
            column1.Name = "ReaderID";

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.HeaderText = "Email";
            column2.Name = "Email";

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.HeaderText = "Address";
            column3.Name = "Address";

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.HeaderText = "PhoneNo";
            column4.Name = "PhoneNo";

            // Add columns to the DataGridView control
            dtgReader.Columns.Add(column1);
            dtgReader.Columns.Add(column2);
            dtgReader.Columns.Add(column3);
            dtgReader.Columns.Add(column4);


            dtgReader.Columns["ReaderID"].DataPropertyName = "ReaderID";
            dtgReader.Columns["Email"].DataPropertyName = "Email";
            dtgReader.Columns["Address"].DataPropertyName = "Address";
            dtgReader.Columns["PhoneNo"].DataPropertyName = "PhoneNo";


            dtgReader.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            foreach (DataGridViewColumn column in dtgReader.Columns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            GetData();
        }

        private void GetData()
        {
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Reader";

                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);

                    // Create a new instance of the DataGridView
                    dtgReader.DataSource = dataTable;


                }
            }
        }
        private void Reader_Load(object sender, EventArgs e)
        {
            // Calculate the center position of the screen
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;
            int formWidth = this.Width;
            int formHeight = this.Height;

            int left = (screenWidth - formWidth) / 2;
            int top = (screenHeight - formHeight) / 2;

            // Set the form's location to center screen
            this.Location = new Point(left, top);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            LoadData();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string readerid = txtReaderID.Text;
            string email = txtEmail.Text;
            string address = txtAddress.Text;
            string phoneno = txtPhoneNo.Text;

            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO Reader (ReaderID, Email, Address, PhoneNo) " +
                                     "VALUES (@Readerid, @Email, @Address, @PhoneNo)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Set parameter values
                    command.Parameters.AddWithValue("@Readerid", readerid);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Address", address);
                    command.Parameters.AddWithValue("@PhoneNo", phoneno);
                    // Execute the query
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Data inserted successfully.");

            GetData();
        }
    }
}
