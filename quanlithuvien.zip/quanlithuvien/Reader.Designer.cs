﻿namespace quanlithuvien
{
    partial class Reader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExit = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            dtgReader = new DataGridView();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtPhoneNo = new TextBox();
            txtAddress = new TextBox();
            txtReaderID = new TextBox();
            txtEmail = new TextBox();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dtgReader).BeginInit();
            SuspendLayout();
            // 
            // btnExit
            // 
            btnExit.Location = new Point(1235, 718);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(250, 147);
            btnExit.TabIndex = 12;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(897, 338);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(213, 55);
            btnDelete.TabIndex = 13;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(897, 252);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(213, 55);
            btnUpdate.TabIndex = 14;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(897, 170);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(213, 55);
            btnAdd.TabIndex = 15;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // dtgReader
            // 
            dtgReader.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgReader.Location = new Point(127, 425);
            dtgReader.Name = "dtgReader";
            dtgReader.RowHeadersWidth = 102;
            dtgReader.RowTemplate.Height = 49;
            dtgReader.Size = new Size(1085, 440);
            dtgReader.TabIndex = 11;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(407, 54);
            label4.Name = "label4";
            label4.Size = new Size(619, 81);
            label4.TabIndex = 7;
            label4.Text = "Reader Management";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(232, 370);
            label3.Name = "label3";
            label3.Size = new Size(143, 41);
            label3.TabIndex = 8;
            label3.Text = "PhoneNo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(232, 306);
            label2.Name = "label2";
            label2.Size = new Size(125, 41);
            label2.TabIndex = 9;
            label2.Text = "Address";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(232, 247);
            label1.Name = "label1";
            label1.Size = new Size(88, 41);
            label1.TabIndex = 10;
            label1.Text = "Email";
            // 
            // txtPhoneNo
            // 
            txtPhoneNo.Location = new Point(429, 370);
            txtPhoneNo.Name = "txtPhoneNo";
            txtPhoneNo.Size = new Size(395, 47);
            txtPhoneNo.TabIndex = 4;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(429, 307);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(395, 47);
            txtAddress.TabIndex = 5;
            // 
            // txtReaderID
            // 
            txtReaderID.Location = new Point(429, 178);
            txtReaderID.Name = "txtReaderID";
            txtReaderID.Size = new Size(395, 47);
            txtReaderID.TabIndex = 6;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(429, 241);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(395, 47);
            txtEmail.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(232, 184);
            label5.Name = "label5";
            label5.Size = new Size(147, 41);
            label5.TabIndex = 10;
            label5.Text = "Reader ID";
            // 
            // Reader
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 255, 192);
            ClientSize = new Size(1535, 922);
            Controls.Add(btnExit);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dtgReader);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label5);
            Controls.Add(label1);
            Controls.Add(txtPhoneNo);
            Controls.Add(txtAddress);
            Controls.Add(txtEmail);
            Controls.Add(txtReaderID);
            Name = "Reader";
            Text = "Reader Management";
            Load += Reader_Load;
            ((System.ComponentModel.ISupportInitialize)dtgReader).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnExit;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private DataGridView dtgReader;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtPhoneNo;
        private TextBox txtAddress;
        private TextBox txtReaderID;
        private TextBox txtEmail;
        private Label label5;
    }
}