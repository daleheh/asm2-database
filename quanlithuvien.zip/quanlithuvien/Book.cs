﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace quanlithuvien
{
    public partial class Book : Form
    {
        public Book()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f = new MainForm();
            f.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string bookid = txtBookID.Text;
            string title = txtTitle.Text;
            string authorid = txtAuthorID.Text;
            string publisherid = txtPublisherID.Text;
            string category = txtCategory.Text;
            string price = txtPrice.Text;
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string Query = @"INSERT INTO Book (BookID, Title, AuthorID, PublisherID, Category, Price) " +
                "VALUES (@Bookid, @Title, @Authorid, @Publisherid, @Category, @Price)";
                using (SqlCommand command = new SqlCommand(Query, connection))
                {
                    // Set parameter values
                    command.Parameters.AddWithValue("@Bookid", bookid);
                    command.Parameters.AddWithValue("@Title", title);
                    command.Parameters.AddWithValue("@Authorid", authorid);
                    command.Parameters.AddWithValue("@Publisherid", publisherid);
                    command.Parameters.AddWithValue("@Category", category);
                    command.Parameters.AddWithValue("@Price", price);
                    // Execute the query
                    command.ExecuteNonQuery();
                }
            }

            Console.WriteLine("Data inserted successfully.");
            Console.ReadLine();

            GetData();
        }
        public void LoadData()
        {
            // Create columns
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.HeaderText = "BookID";
            column1.Name = "BookID";

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.HeaderText = "Title";
            column2.Name = "Title";

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.HeaderText = "AuthorID";
            column3.Name = "AuthorID";


            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.HeaderText = "PublisherID";
            column4.Name = "PublisherID";

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.HeaderText = "Category";
            column5.Name = "Category";

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.HeaderText = "Price";
            column6.Name = "Price";

            // Add columns to the DataGridView control
            dataGridView1.Columns.Add(column1);
            dataGridView1.Columns.Add(column2);
            dataGridView1.Columns.Add(column3);
            dataGridView1.Columns.Add(column4);
            dataGridView1.Columns.Add(column5);
            dataGridView1.Columns.Add(column6);


            dataGridView1.Columns["BookID"].DataPropertyName = "BookID";
            dataGridView1.Columns["Title"].DataPropertyName = "Title";
            dataGridView1.Columns["AuthorID"].DataPropertyName = "AuthorID";
            dataGridView1.Columns["PublisherID"].DataPropertyName = "PublisherID";
            dataGridView1.Columns["Category"].DataPropertyName = "Category";
            dataGridView1.Columns["Price"].DataPropertyName = "Price";


            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            GetData();
        }


        private void GetData()
        {
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Book";

                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);
                    // Create a new instance of the DataGridView
                    dataGridView1.DataSource = dataTable;


                }
            }
        }

        private void Book_Load(object sender, EventArgs e)
        {
            // Calculate the center position of the screen
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;
            int formWidth = this.Width;
            int formHeight = this.Height;

            int left = (screenWidth - formWidth) / 2;
            int top = (screenHeight - formHeight) / 2;

            // Set the form's location to center screen
            this.Location = new Point(left, top);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            LoadData();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Get input values
            int bookid;
            if (!int.TryParse(txtPublisherID.Text, out bookid))
            {
                MessageBox.Show("Please enter a valid Publisher ID.");
                return;
            }

            string title = txtTitle.Text;
            string authorid = txtAuthorID.Text;
            string publisherid = txtPublisherID.Text;
            string category = txtCategory.Text;
            string price = txtPrice.Text;

            // Connection string
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=FPT University's Online Library System;Integrated Security=True";

            // SQL query for update
            string updateQuery = "UPDATE Book SET Title = @Title, AuthorID = @Authorid, PublisherID = @Publisherid, Category = @Category, Price = @Price WHERE BookID = @Bookid";

            // Create SqlConnection and SqlCommand objects within 'using' block to ensure proper disposal
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // Add parameters with appropriate data types
                    command.Parameters.AddWithValue("@Bookid", bookid);
                    command.Parameters.AddWithValue("@Title", title);
                    command.Parameters.AddWithValue("@Authorid", authorid);
                    command.Parameters.AddWithValue("@Publisherid", publisherid);
                    command.Parameters.AddWithValue("@Category", category);
                    command.Parameters.AddWithValue("@Price", price);

                    try
                    {
                        // Open connection
                        connection.Open();

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated successfully.");
                            GetData(); // Refresh data display if needed
                        }
                        else
                        {
                            MessageBox.Show("No rows updated. Publisher ID not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating data: " + ex.Message);
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            // Get the PublisherID from the textbox
            if (!int.TryParse(txtBookID.Text, out int bookid))
            {
                MessageBox.Show("Please enter a valid Book ID.");
                return;
            }

            // Connection string
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=FPT University's Online Library System;Integrated Security=True";

            // SQL query for delete
            string deleteQuery = "DELETE FROM Book WHERE BookID = @Bookid";

            // Create SqlConnection and SqlCommand objects within 'using' block to ensure proper disposal
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    // Add parameter for PublisherID
                    command.Parameters.AddWithValue("@Bookid", bookid);

                    try
                    {
                        // Open connection
                        connection.Open();

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data deleted successfully.");
                            GetData(); // Refresh data display if needed
                        }
                        else
                        {
                            MessageBox.Show("No rows deleted. Book ID not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting data: " + ex.Message);
                    }
                }
            }
        }
    }
}
