using System.Data.SqlClient;

namespace quanlithuvien
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string user = "dat";
        string pass = "123";
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                MessageBox.Show("You haven't enter the account");
                txtUsername.Focus();


            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("You haven't enter the password");
                txtPassword.Focus();
            }
            else if (user.Equals(txtUsername.Text) && pass.Equals(txtPassword.Text))
            {

                MessageBox.Show("Login Successfully");
                this.Hide();
                Form f = new MainForm();
                f.Show();
            }
            else { MessageBox.Show("Wrong account or password!"); }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;
            int formWidth = this.Width;
            int formHeight = this.Height;

            int left = (screenWidth - formWidth) / 2;
            int top = (screenHeight - formHeight) / 2;

            // Set the form's location to center screen
            this.Location = new Point(left, top);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }
    }
}