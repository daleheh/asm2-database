﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlithuvien
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report sf = new Report();
            sf.ShowDialog();
            this.Close();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            this.Hide();
            Book sf = new Book();
            sf.ShowDialog();
            this.Close();
        }

        private void btnPublish_Click(object sender, EventArgs e)
        {
            this.Hide();
            PublisherForm sf = new PublisherForm();
            sf.ShowDialog();
            this.Close();
        }

        private void btnReader_Click(object sender, EventArgs e)
        {
            this.Hide();
            Reader sf = new Reader();
            sf.ShowDialog();
            this.Close();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            this.Hide();
            Staff sf = new Staff();
            sf.ShowDialog();
            this.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Calculate the center position of the screen
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;
            int formWidth = this.Width;
            int formHeight = this.Height;

            int left = (screenWidth - formWidth) / 2;
            int top = (screenHeight - formHeight) / 2;

            // Set the form's location to center screen
            this.Location = new Point(left, top);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }
    }
}
