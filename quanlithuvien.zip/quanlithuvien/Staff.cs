﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace quanlithuvien
{
    public partial class Staff : Form
    {
        public Staff()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f = new MainForm();
            f.Show();
        }


        private void Staff_Load(object sender, EventArgs e)
        {
            // Calculate the center position of the screen
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;
            int formWidth = this.Width;
            int formHeight = this.Height;

            int left = (screenWidth - formWidth) / 2;
            int top = (screenHeight - formHeight) / 2;

            // Set the form's location to center screen
            this.Location = new Point(left, top);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            LoadData();
        }
        public void LoadData()
        {
            // Create columns
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.HeaderText = "StaffID";
            column1.Name = "StaffID";

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.HeaderText = "Name";
            column2.Name = "Name";

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.HeaderText = "position";
            column3.Name = "position";

            // Add columns to the DataGridView control
            dataGridView1.Columns.Add(column1);
            dataGridView1.Columns.Add(column2);
            dataGridView1.Columns.Add(column3);


            dataGridView1.Columns["StaffID"].DataPropertyName = "StaffID";
            dataGridView1.Columns["Name"].DataPropertyName = "Name";
            dataGridView1.Columns["position"].DataPropertyName = "position";

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            GetData();
        }

        private void GetData()
        {
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Staff";

                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);

                    // Create a new instance of the DataGridView
                    dataGridView1.DataSource = dataTable;

                }
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string staffid = txtStaffID.Text;
            string position = txtPosition.Text;

            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO Staff (StaffID, Name, position) " +
                                     "VALUES (@Staffid, @Name, @position)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Set parameter values
                    command.Parameters.AddWithValue("@Staffid", staffid);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@position", position);
                    // Execute the query
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Data inserted successfully.");

            GetData();

        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            // Get input values
            int staffid;
            if (!int.TryParse(txtStaffID.Text, out staffid))
            {
                MessageBox.Show("Please enter a valid Staff ID.");
                return;
            }

            string name = txtName.Text;
            string position = txtPosition.Text;

            // Connection string
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=FPT University's Online Library System;Integrated Security=True";

            // SQL query for update
            string updateQuery = "UPDATE Staff SET Name = @Name, position = @position WHERE StaffID = @Staffid";

            // Create SqlConnection and SqlCommand objects within 'using' block to ensure proper disposal
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // Add parameters with appropriate data types
                    command.Parameters.AddWithValue("@Staffid", staffid);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@position", position);

                    try
                    {
                        // Open connection
                        connection.Open();

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated successfully.");
                            GetData(); // Refresh data display if needed
                        }
                        else
                        {
                            MessageBox.Show("No rows updated. Staff ID not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating data: " + ex.Message);
                    }
                }
            }
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            // Get the PublisherID from the textbox
            if (!int.TryParse(txtStaffID.Text, out int staffid))
            {
                MessageBox.Show("Please enter a valid Staff ID.");
                return;
            }

            // Connection string
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=FPT University's Online Library System;Integrated Security=True";

            // SQL query for delete
            string deleteQuery = "DELETE FROM Staff WHERE StaffID = @Staffid";

            // Create SqlConnection and SqlCommand objects within 'using' block to ensure proper disposal
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    // Add parameter for PublisherID
                    command.Parameters.AddWithValue("@Staffid", staffid);

                    try
                    {
                        // Open connection
                        connection.Open();

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data deleted successfully.");
                            GetData(); // Refresh data display if needed
                        }
                        else
                        {
                            MessageBox.Show("No rows deleted. Staff ID not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting data: " + ex.Message);
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
