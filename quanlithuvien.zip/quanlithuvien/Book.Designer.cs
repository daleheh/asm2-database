﻿namespace quanlithuvien
{
    partial class Book
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExit = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtAuthorID = new TextBox();
            txtTitle = new TextBox();
            txtBookID = new TextBox();
            label5 = new Label();
            txtPublisherID = new TextBox();
            txtPrice = new TextBox();
            label6 = new Label();
            txtCategory = new TextBox();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnExit
            // 
            btnExit.Location = new Point(996, 455);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(198, 130);
            btnExit.TabIndex = 12;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += button4_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(1006, 340);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(188, 58);
            btnDelete.TabIndex = 13;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(1006, 261);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(188, 58);
            btnUpdate.TabIndex = 14;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(1006, 179);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(188, 58);
            btnAdd.TabIndex = 15;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(59, 424);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 102;
            dataGridView1.RowTemplate.Height = 49;
            dataGridView1.Size = new Size(925, 413);
            dataGridView1.TabIndex = 11;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(387, 57);
            label4.Name = "label4";
            label4.Size = new Size(597, 81);
            label4.TabIndex = 7;
            label4.Text = "Book Management";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(59, 349);
            label3.Name = "label3";
            label3.Size = new Size(146, 41);
            label3.TabIndex = 8;
            label3.Text = "Author ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(59, 270);
            label2.Name = "label2";
            label2.Size = new Size(74, 41);
            label2.TabIndex = 9;
            label2.Text = "Title";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(59, 196);
            label1.Name = "label1";
            label1.Size = new Size(123, 41);
            label1.TabIndex = 10;
            label1.Text = "Book ID";
            // 
            // txtAuthorID
            // 
            txtAuthorID.Location = new Point(216, 343);
            txtAuthorID.Name = "txtAuthorID";
            txtAuthorID.Size = new Size(250, 47);
            txtAuthorID.TabIndex = 4;
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(216, 264);
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(250, 47);
            txtTitle.TabIndex = 5;
            // 
            // txtBookID
            // 
            txtBookID.Location = new Point(216, 196);
            txtBookID.Name = "txtBookID";
            txtBookID.Size = new Size(250, 47);
            txtBookID.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(501, 196);
            label5.Name = "label5";
            label5.Size = new Size(177, 41);
            label5.TabIndex = 17;
            label5.Text = "Publisher ID";
            // 
            // txtPublisherID
            // 
            txtPublisherID.Location = new Point(677, 196);
            txtPublisherID.Name = "txtPublisherID";
            txtPublisherID.Size = new Size(250, 47);
            txtPublisherID.TabIndex = 16;
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(677, 340);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(250, 47);
            txtPrice.TabIndex = 16;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(501, 343);
            label6.Name = "label6";
            label6.Size = new Size(82, 41);
            label6.TabIndex = 17;
            label6.Text = "Price";
            // 
            // txtCategory
            // 
            txtCategory.Location = new Point(677, 264);
            txtCategory.Name = "txtCategory";
            txtCategory.Size = new Size(250, 47);
            txtCategory.TabIndex = 16;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(501, 264);
            label7.Name = "label7";
            label7.Size = new Size(139, 41);
            label7.TabIndex = 17;
            label7.Text = "Category";
            // 
            // Book
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PeachPuff;
            ClientSize = new Size(1316, 904);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txtCategory);
            Controls.Add(txtPrice);
            Controls.Add(txtPublisherID);
            Controls.Add(btnExit);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtAuthorID);
            Controls.Add(txtTitle);
            Controls.Add(txtBookID);
            Name = "Book";
            Text = "Book Management";
            Load += Book_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnExit;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private DataGridView dataGridView1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtAuthorID;
        private TextBox txtTitle;
        private TextBox txtBookID;
        private Label label5;
        private TextBox txtPublisherID;
        private TextBox txtPrice;
        private Label label6;
        private TextBox txtCategory;
        private Label label7;
    }
}