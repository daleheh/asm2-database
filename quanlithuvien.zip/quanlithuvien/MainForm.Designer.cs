﻿namespace quanlithuvien
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnHome = new Button();
            btnReport = new Button();
            btnBook = new Button();
            btnReader = new Button();
            btnPublish = new Button();
            btnAdmin = new Button();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            monthCalendar1 = new MonthCalendar();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // btnHome
            // 
            btnHome.Location = new Point(1, 49);
            btnHome.Margin = new Padding(1);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(77, 21);
            btnHome.TabIndex = 0;
            btnHome.Text = "Home";
            btnHome.UseVisualStyleBackColor = true;
            // 
            // btnReport
            // 
            btnReport.Location = new Point(76, 49);
            btnReport.Margin = new Padding(1);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(77, 21);
            btnReport.TabIndex = 0;
            btnReport.Text = "Report";
            btnReport.UseVisualStyleBackColor = true;
            btnReport.Click += button2_Click;
            // 
            // btnBook
            // 
            btnBook.Location = new Point(152, 49);
            btnBook.Margin = new Padding(1);
            btnBook.Name = "btnBook";
            btnBook.Size = new Size(77, 21);
            btnBook.TabIndex = 0;
            btnBook.Text = "Book";
            btnBook.UseVisualStyleBackColor = true;
            btnBook.Click += btnBook_Click;
            // 
            // btnReader
            // 
            btnReader.Location = new Point(301, 49);
            btnReader.Margin = new Padding(1);
            btnReader.Name = "btnReader";
            btnReader.Size = new Size(77, 21);
            btnReader.TabIndex = 0;
            btnReader.Text = "Reader";
            btnReader.UseVisualStyleBackColor = true;
            btnReader.Click += btnReader_Click;
            // 
            // btnPublish
            // 
            btnPublish.Location = new Point(226, 49);
            btnPublish.Margin = new Padding(1);
            btnPublish.Name = "btnPublish";
            btnPublish.Size = new Size(77, 21);
            btnPublish.TabIndex = 0;
            btnPublish.Text = "Publisher";
            btnPublish.UseVisualStyleBackColor = true;
            btnPublish.Click += btnPublish_Click;
            // 
            // btnAdmin
            // 
            btnAdmin.Location = new Point(376, 49);
            btnAdmin.Margin = new Padding(1);
            btnAdmin.Name = "btnAdmin";
            btnAdmin.Size = new Size(77, 21);
            btnAdmin.TabIndex = 0;
            btnAdmin.Text = "Admin";
            btnAdmin.UseVisualStyleBackColor = true;
            btnAdmin.Click += btnAdmin_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ActiveCaption;
            pictureBox1.Image = Properties.Resources.van_la_sach_nma_chuan;
            pictureBox1.Location = new Point(1, 72);
            pictureBox1.Margin = new Padding(1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(892, 348);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.btec;
            pictureBox2.Location = new Point(583, 1);
            pictureBox2.Margin = new Padding(1);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(198, 69);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 20.1F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(252, 9);
            label1.Margin = new Padding(1, 0, 1, 0);
            label1.Name = "label1";
            label1.Size = new Size(301, 37);
            label1.TabIndex = 4;
            label1.Text = "Online library system";
            // 
            // monthCalendar1
            // 
            monthCalendar1.Location = new Point(1, 72);
            monthCalendar1.Margin = new Padding(4, 3, 4, 3);
            monthCalendar1.Name = "monthCalendar1";
            monthCalendar1.TabIndex = 5;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(903, 430);
            Controls.Add(monthCalendar1);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(btnPublish);
            Controls.Add(btnAdmin);
            Controls.Add(btnReader);
            Controls.Add(btnBook);
            Controls.Add(btnReport);
            Controls.Add(btnHome);
            Margin = new Padding(1);
            Name = "MainForm";
            Text = "MainForm";
            Load += MainForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnHome;
        private Button btnReport;
        private Button btnBook;
        private Button btnReader;
        private Button btnPublish;
        private Button btnAdmin;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label1;
        private MonthCalendar monthCalendar1;
    }
}