﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using System.Xml.Linq;

namespace quanlithuvien
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }

        private void Report_Load(object sender, EventArgs e)
        {
            // Calculate the center position of the screen
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;
            int formWidth = this.Width;
            int formHeight = this.Height;

            int left = (screenWidth - formWidth) / 2;
            int top = (screenHeight - formHeight) / 2;

            // Set the form's location to center screen
            this.Location = new Point(left, top);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            LoadData();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string staffid = txtStaff.Text;
            string reportid = txtReportID.Text;
            string bookid = txtBookID.Text;
            string readerid = txtReaderID.Text;

            DateTime borrowingdate = dtpBorrowingDate.Value;
            DateTime returndate = borrowingdate.AddDays(3);
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO Reports (ReportID, BookID, ReaderID, StaffID, BorrowingDate, ReturnDate) " +
                                     "VALUES (@Report, @Book, @Reader,@Staff, @Borrowingdate, @Returndate)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Report", reportid);
                    command.Parameters.AddWithValue("@Book", bookid);
                    command.Parameters.AddWithValue("@Reader", readerid);
                    command.Parameters.AddWithValue("@Staff", staffid);
                    command.Parameters.AddWithValue("@Borrowingdate", borrowingdate);
                    command.Parameters.AddWithValue("@Returndate", returndate);
                    int rowsAffected = command.ExecuteNonQuery();

                    // Check if any rows were affected
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data inserted successfully into Reports table.");
                    }
                    else
                    {
                        MessageBox.Show("No rows were affected. Data may not have been inserted.");
                    }
                }

            }


            Console.WriteLine("Data inserted successfully.");
            Console.ReadLine();

            GetData();
        }
        public void LoadData()
        {
            // Create columns
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.HeaderText = "ReportID";
            column1.Name = "ReportID";

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.HeaderText = "BookID";
            column2.Name = "BookID";

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.HeaderText = "ReaderID";
            column3.Name = "ReaderID";

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.HeaderText = "StaffID";
            column4.Name = "StaffID";

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.HeaderText = "BorrowingDate";
            column5.Name = "BorrowingDate";

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.HeaderText = "ReturnDate";
            column6.Name = "ReturnDate";

            // Add columns to the DataGridView control
            dataGridView1.Columns.Add(column1);
            dataGridView1.Columns.Add(column2);
            dataGridView1.Columns.Add(column3);
            dataGridView1.Columns.Add(column4);
            dataGridView1.Columns.Add(column5);
            dataGridView1.Columns.Add(column6);


            dataGridView1.Columns["ReportID"].DataPropertyName = "ReportID";
            dataGridView1.Columns["ReaderID"].DataPropertyName = "ReaderID";
            dataGridView1.Columns["BookID"].DataPropertyName = "BookID";
            dataGridView1.Columns["StaffID"].DataPropertyName = "StaffID";
            dataGridView1.Columns["BorrowingDate"].DataPropertyName = "BorrowingDate";
            dataGridView1.Columns["ReturnDate"].DataPropertyName = "ReturnDate";


            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            GetData();
        }


        private void GetData()
        {
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Reports";

                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);

                    // Create a new instance of the DataGridView
                    dataGridView1.DataSource = dataTable;


                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Get input values
            int reportid;
            if (!int.TryParse(txtReportID.Text, out reportid))
            {
                MessageBox.Show("Please enter a valid Report ID.");
                return;
            }

            string staffid = txtStaff.Text;
            string bookid = txtBookID.Text;
            string readerid = txtReaderID.Text;

            DateTime borrowingdate = dtpBorrowingDate.Value;
            DateTime returndate = borrowingdate.AddDays(3);

            // Connection string
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=FPT University's Online Library System;Integrated Security=True";

            // SQL query for update
            string updateQuery = "UPDATE Reports SET BookID = @Book, ReaderID = @Reader, StaffID = @Staff, BorrowingDate = @Borrowingdate, ReturnDate = @Returndate WHERE ReportID = @Report";

            // Create SqlConnection and SqlCommand objects within 'using' block to ensure proper disposal
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // Add parameters with appropriate data types
                    command.Parameters.AddWithValue("@Report", reportid);
                    command.Parameters.AddWithValue("@Book", bookid);
                    command.Parameters.AddWithValue("@Reader", readerid);
                    command.Parameters.AddWithValue("@Staff", staffid);
                    command.Parameters.AddWithValue("@Borrowingdate", borrowingdate);
                    command.Parameters.AddWithValue("@Returndate", returndate);

                    try
                    {
                        // Open connection
                        connection.Open();

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated successfully.");
                            GetData(); // Refresh data display if needed
                        }
                        else
                        {
                            MessageBox.Show("No rows updated. Report ID not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating data: " + ex.Message);
                    }
                }
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f = new MainForm();
            f.Show();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int reportid;
            // Get the PublisherID from the textbox
            if (!int.TryParse(txtReportID.Text, out reportid))
            {
                MessageBox.Show("Please enter a valid Report ID.");
                return;
            }

            // Connection string
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=FPT University's Online Library System;Integrated Security=True";

            // SQL query for delete
            string deleteQuery = "DELETE FROM Reports WHERE ReportID = @Reportid";

            // Create SqlConnection and SqlCommand objects within 'using' block to ensure proper disposal
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    // Add parameter for PublisherID
                    command.Parameters.AddWithValue("@Reportid", reportid);

                    try
                    {
                        // Open connection
                        connection.Open();

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data deleted successfully.");
                            GetData(); // Refresh data display if needed
                        }
                        else
                        {
                            MessageBox.Show("No rows deleted. Report ID not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting data: " + ex.Message);
                    }
                }
            };
        }

    }
}
