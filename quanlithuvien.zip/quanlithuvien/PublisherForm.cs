﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace quanlithuvien
{
    public partial class PublisherForm : Form
    {
        public PublisherForm()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f = new MainForm();
            f.Show();
        }


        public void LoadData()
        {
            // Create columns
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.HeaderText = "PublisherID";
            column1.Name = "PublisherID";

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.HeaderText = "Name";
            column2.Name = "Name";

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.HeaderText = "YearOfPublication";
            column3.Name = "YearOfPublication";

            // Add columns to the DataGridView control
            dataGridView1.Columns.Add(column1);
            dataGridView1.Columns.Add(column2);
            dataGridView1.Columns.Add(column3);


            dataGridView1.Columns["PublisherID"].DataPropertyName = "PublisherID";
            dataGridView1.Columns["YearOfPublication"].DataPropertyName = "YearOfPublication";
            dataGridView1.Columns["Name"].DataPropertyName = "Name";


            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            GetData();
        }

        private void GetData()
        {
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Publisher";

                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);

                    // Create a new instance of the DataGridView
                    dataGridView1.DataSource = dataTable;


                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string publisherid = txtPublisherID.Text;
            string yearofpublication = txtYearOfPublication.Text;

            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=\"FPT University's Online Library System\";Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO Publisher (PublisherID, Name, YearOfPublication) " +
                                     "VALUES (@Publisherid, @Name, @Yearofpublication)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Set parameter values
                    command.Parameters.AddWithValue("@Publisherid", publisherid);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Yearofpublication", yearofpublication);
                    // Execute the query
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Data inserted successfully.");
            GetData();

        }

        private void PublisherForm_Load(object sender, EventArgs e)
        {
            // Calculate the center position of the screen
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;
            int formWidth = this.Width;
            int formHeight = this.Height;

            int left = (screenWidth - formWidth) / 2;
            int top = (screenHeight - formHeight) / 2;

            // Set the form's location to center screen
            this.Location = new Point(left, top);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            LoadData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Get input values
            int publisherId;
            if (!int.TryParse(txtPublisherID.Text, out publisherId))
            {
                MessageBox.Show("Please enter a valid Publisher ID.");
                return;
            }

            string name = txtName.Text;
            string yearOfPublication = txtYearOfPublication.Text;

            // Connection string
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=FPT University's Online Library System;Integrated Security=True";

            // SQL query for update
            string updateQuery = "UPDATE Publisher SET Name = @Name, YearOfPublication = @YearOfPublication WHERE PublisherID = @PublisherId";

            // Create SqlConnection and SqlCommand objects within 'using' block to ensure proper disposal
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // Add parameters with appropriate data types
                    command.Parameters.AddWithValue("@PublisherId", publisherId);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@YearOfPublication", yearOfPublication);

                    try
                    {
                        // Open connection
                        connection.Open();

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated successfully.");
                            GetData(); // Refresh data display if needed
                        }
                        else
                        {
                            MessageBox.Show("No rows updated. Publisher ID not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating data: " + ex.Message);
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Get the PublisherID from the textbox
            if (!int.TryParse(txtPublisherID.Text, out int publisherId))
            {
                MessageBox.Show("Please enter a valid Publisher ID.");
                return;
            }

            // Connection string
            string connectionString = "Data Source=DESKTOP-108BF7P\\MSSQLSERVER01;Initial Catalog=FPT University's Online Library System;Integrated Security=True";

            // SQL query for delete
            string deleteQuery = "DELETE FROM Publisher WHERE PublisherID = @PublisherId";

            // Create SqlConnection and SqlCommand objects within 'using' block to ensure proper disposal
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    // Add parameter for PublisherID
                    command.Parameters.AddWithValue("@PublisherId", publisherId);

                    try
                    {
                        // Open connection
                        connection.Open();

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data deleted successfully.");
                            GetData(); // Refresh data display if needed
                        }
                        else
                        {
                            MessageBox.Show("No rows deleted. Publisher ID not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting data: " + ex.Message);
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
