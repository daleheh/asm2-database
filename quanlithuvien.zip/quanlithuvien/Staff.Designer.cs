﻿namespace quanlithuvien
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExit = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtPosition = new TextBox();
            txtName = new TextBox();
            txtStaffID = new TextBox();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnExit
            // 
            btnExit.Location = new Point(1019, 464);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(230, 137);
            btnExit.TabIndex = 12;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += button4_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(792, 258);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(188, 58);
            btnDelete.TabIndex = 13;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click_1;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(792, 185);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(188, 58);
            btnUpdate.TabIndex = 14;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click_1;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(792, 110);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(188, 58);
            btnAdd.TabIndex = 15;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(48, 343);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 102;
            dataGridView1.RowTemplate.Height = 49;
            dataGridView1.Size = new Size(932, 488);
            dataGridView1.TabIndex = 11;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(624, -40);
            label4.Name = "label4";
            label4.Size = new Size(97, 41);
            label4.TabIndex = 7;
            label4.Text = "label1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(75, 247);
            label3.Name = "label3";
            label3.Size = new Size(124, 41);
            label3.TabIndex = 8;
            label3.Text = "Position";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(75, 185);
            label2.Name = "label2";
            label2.Size = new Size(97, 41);
            label2.TabIndex = 9;
            label2.Text = "Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(75, 116);
            label1.Name = "label1";
            label1.Size = new Size(113, 41);
            label1.TabIndex = 10;
            label1.Text = "Staff ID";
            // 
            // txtPosition
            // 
            txtPosition.Location = new Point(276, 258);
            txtPosition.Name = "txtPosition";
            txtPosition.Size = new Size(429, 47);
            txtPosition.TabIndex = 4;
            // 
            // txtName
            // 
            txtName.Location = new Point(276, 185);
            txtName.Name = "txtName";
            txtName.Size = new Size(429, 47);
            txtName.TabIndex = 5;
            // 
            // txtStaffID
            // 
            txtStaffID.Location = new Point(276, 116);
            txtStaffID.Name = "txtStaffID";
            txtStaffID.Size = new Size(429, 47);
            txtStaffID.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(356, 9);
            label5.Name = "label5";
            label5.Size = new Size(558, 81);
            label5.TabIndex = 10;
            label5.Text = "Staff Management";
            // 
            // Staff
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 192, 255);
            ClientSize = new Size(1307, 870);
            Controls.Add(btnExit);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label5);
            Controls.Add(label1);
            Controls.Add(txtPosition);
            Controls.Add(txtName);
            Controls.Add(txtStaffID);
            Name = "Staff";
            Text = "Staff mangement";
            Load += Staff_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnExit;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private DataGridView dataGridView1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtPosition;
        private TextBox txtName;
        private TextBox txtStaffID;
        private Label label5;
    }
}